using UnityEngine;
using System.Collections;

public class RoundsUI : MonoBehaviour {

	public TextMesh roundsText;
	
	// Update is called once per frame
	void Update () {
		if ( PlayerStats.Rounds > 1 )
			roundsText.text = PlayerStats.Rounds.ToString() + " ROUNDS";
		else
			roundsText.text = PlayerStats.Rounds.ToString() + " ROUND";
	}
}
