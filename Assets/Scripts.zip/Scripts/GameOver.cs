using UnityEngine;
using System.Collections;

public class GameOver : MonoBehaviour {
	
	public string mainSceneName;
	public string menuScene;
	public SceneFader sceneFader;
	
	public void Retry() {
		sceneFader.FadeTo( mainSceneName );
	}
	
	public void Menu() {
		sceneFader.FadeTo( menuScene );
	}
}
