using UnityEngine;

[System.Serializable]
public class CustomUI {
	public Rect rectPercent;
	public string text;
	public GUIStyle style;
	public float fontSizePercent;
}