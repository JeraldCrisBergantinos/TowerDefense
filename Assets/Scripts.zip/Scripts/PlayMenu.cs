using UnityEngine;
using System.Collections;

public class PlayMenu : MonoBehaviour {
	
	public string mainSceneName;
	public SceneFader sceneFader;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	
	void OnMouseDown() {
		sceneFader.FadeTo( mainSceneName );
	}
}
