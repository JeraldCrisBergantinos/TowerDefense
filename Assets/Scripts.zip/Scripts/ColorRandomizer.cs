using UnityEngine;

public class ColorRandomizer {

	public static Color GetRandomColor() {
		float r = 0f;
		float g = Random.Range( 0.25f, 1f );
		float b = Random.Range( 0.25f, 1f );
		float a = 1f;
		return new Color( r, g, b, a );
	}
	
}
