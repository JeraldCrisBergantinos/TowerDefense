using UnityEngine;
using System.Collections;

public class SoundLoop : MonoBehaviour {
	
	public static SoundLoop instance;
	
	public Vector3[] positions;
	public Transform bgSound;
	public float interval = 5f;
	public Transform[] spheres;
	public Animation[] animations;
	public float sphereScale;
	public SoundEffects soundEffects;
	
	private int index;
	private bool correctKey;
	private Vector3[] startScaleSpheres;
	
	void Awake() {
		if ( instance != null ) {
			Debug.LogError( "More than one SoundLoop in the scene." );
			return;
		}
		
		instance = this;
	}

	// Use this for initialization
	void Start () {
		index = -1;
		correctKey = false;
		
		SetStartScale();
		StopAnimation();
		StartCoroutine( Loop() );
	}
	
	// Update is called once per frame
	void Update () {
		CheckKey();
	}
	
	IEnumerator Loop() {
		while ( true ) {
			ResetScale();
			StopAnimation();
			
			int i = Random.Range( 0, positions.Length );
			index = i;
			bgSound.localPosition = positions[i];
			spheres[i].localScale = startScaleSpheres[i] * sphereScale;
			animations[i].enabled = true;
			soundEffects.channel = ( i%2 );
			yield return new WaitForSeconds( interval );
		}
	}
	
	void CheckKey() {
		if ( Input.GetKey(KeyCode.LeftArrow) ) {
			if ( index == 0 ) {
				correctKey = true;
			}
			else {
				correctKey = false;
			}
		}
		else if ( Input.GetKey(KeyCode.RightArrow) ) {
			if ( index == 1 ) {
				correctKey = true;
			}
			else {
				correctKey = false;
			}
		}
		else if ( Input.GetKeyUp(KeyCode.LeftArrow) ||
			Input.GetKeyUp(KeyCode.RightArrow) ) {
			index = -1;
			correctKey = false;
		}
	}
	
	public bool IsCorrectKeyPressed() {
		return correctKey;
	}
	
	void SetStartScale() {
		startScaleSpheres = new Vector3[spheres.Length];
		for (int i = 0; i < spheres.Length; i++) {
			startScaleSpheres[i] = spheres[i].localScale;
		}
	}
	
	void ResetScale() {
		for (int i = 0; i < spheres.Length; i++) {
			spheres[i].localScale = startScaleSpheres[i];
		}
	}
	
	void StopAnimation() {
		foreach (Animation item in animations) {
			item.enabled = false;
		}
	}
}
