using UnityEngine;
using System.Collections;

public class SoundEffects : MonoBehaviour {
	
	public Transform[] nodes;
	public float multiplier = 1f;
	public int channel = 0;
	public float maxHeight = 10f;

	// Use this for initialization
	void Start () {
		if ( nodes.Length < 1 ) {
			GameObject[] temp = GameObject.FindGameObjectsWithTag( "Node" );
			nodes = new Transform[temp.Length];
			
			for (int i = 0; i < nodes.Length; i++) {
				nodes[i] = temp[i].transform;
			}
		}
	}
	
	// Update is called once per frame
	void Update () {
		float[] spectrum = new float[1024];
        AudioListener.GetSpectrumData(spectrum, channel, FFTWindow.Rectangular );
		float l1 = spectrum [0] + spectrum [2] + spectrum [4];
        float l2 = spectrum [10] + spectrum [11] + spectrum [12];
        float l3 = spectrum[20] + spectrum [21] + spectrum [22];
        float l4 = spectrum [40] + spectrum [41] + spectrum [42] + spectrum [43];
        float l5 = spectrum [80] + spectrum [81] + spectrum [82] + spectrum [83];
        float l6 = spectrum [160] + spectrum [161] + spectrum [162] + spectrum [163];
        float l7 = spectrum [320] + spectrum [321] + spectrum [322] + spectrum [323];

		for ( int i = 0; i < nodes.Length; i++ ) {
			Vector3 scale = nodes[i].localScale;
			float y = scale.y;
			
			switch ( i%7 ) {
				case 0:
					y = l1 * 100;
	                break;
	            case 1:
					y = l2 * 200;
	                break;
	            case 2:
					y = l3 * 400;
	                break;
	            case 3:
					y = l4 * 800;
	                break;
	            case 4:
					y = l5 * 1600;
	                break;
	            case 5:
					y = l6 * 3200;
	                break;
	            case 6:
					y = l7 * 6400;
	                break;
			}
			
			y = Mathf.Clamp( y * multiplier, 1f, maxHeight );
			
			nodes[i].localScale = new Vector3( scale.x, y, scale.z );
		}
	}
}
