using UnityEngine;
using System.Collections;

public class PlayerStats : MonoBehaviour {
	
	public static int Money;
	public int startMoney = 400;
	
	public int startLives = 20;
	public static int Rounds;
	
	private static int lives;

	// Use this for initialization
	void Start () {
		Money = startMoney;
		Lives = startLives;
		
		Rounds = 0;
	}
	
	public static int Lives {
		get {
			return lives;
		}
		set {
			if ( value < 0 )
				lives = 0;
			else
				lives = value;
		}
	}
}
