using UnityEngine;
using System.Collections;

public class WaveSpawner : MonoBehaviour {
	
	public static int EnemiesAlive = 0;
	
	public Wave[] waves;
	
	public Transform spawnPoint;
	public float timeBetweenWaves = 5f;
	public TextMesh waveCountDownTimer;
	public AnimationCurve infiniteWaveCurve;
	public string enemyTag = "Enemy";
	
	private float countDown = 2f;
	private int waveIndex = 0;
	private int infiniteWaveCount = 0;
	
	void Update() {
		if ( EnemiesAlive > 0 || GameObject.FindGameObjectsWithTag(enemyTag).Length > 0 ) {
			return;
		}
		
		if ( countDown <= 0f ) {
			StartCoroutine( SpawnWave() );
			countDown = timeBetweenWaves;
			return;
		}
		
		countDown -= Time.deltaTime;
		countDown = Mathf.Clamp( countDown, 0f, Mathf.Infinity );
		waveCountDownTimer.text = string.Format( "{0:00.00}", countDown );
	}
	
	IEnumerator SpawnWave() {
		++PlayerStats.Rounds;
		
		Wave wave = waves[waveIndex];
		EnemiesAlive += wave.count;
		
		if ( wave.infinite ) {
			++infiniteWaveCount;
		}
		else {
			++waveIndex;
		}
		
		for (int i = 0; i < wave.count; i++) {
			SpawnEnemy( wave );
			yield return new WaitForSeconds( 1f / wave.rate );
		}
	}
	
	void SpawnEnemy( Wave wave ) {
		if ( wave.infinite ) {
			int index = Random.Range( 0, wave.enemies.Length );
			GameObject go = Instantiate( wave.enemies[index], spawnPoint.position, spawnPoint.rotation ) as GameObject;
			Enemy e = go.GetComponent<Enemy>();
			int count = Mathf.Clamp( infiniteWaveCount, 1, 100 );
			float multiplier = 1f + infiniteWaveCurve.Evaluate( count * 0.01f );
			Debug.Log( "count: " + count );
			Debug.Log( "count * 0.01f: " + ( count * 0.01f ) );
			Debug.Log( "multiplier: " + multiplier );
			e.startHealth *= wave.healthMultiplier * count;
			e.startSpeed *= wave.speedMultiplier * multiplier;
			e.regenHealth += wave.healthRegenMultiplier * multiplier;
		}
		else {
			GameObject go = Instantiate( wave.enemy, spawnPoint.position, spawnPoint.rotation ) as GameObject;
			Enemy e = go.GetComponent<Enemy>();
			e.startHealth *= wave.healthMultiplier;
			e.startSpeed *= wave.speedMultiplier;
			e.regenHealth += wave.healthRegenMultiplier;
		}
	}
	
}
