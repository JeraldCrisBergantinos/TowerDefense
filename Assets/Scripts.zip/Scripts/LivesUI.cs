using UnityEngine;
using System.Collections;

public class LivesUI : MonoBehaviour {
	
	public TextMesh livesText;
	
	// Update is called once per frame
	void Update () {
		if ( PlayerStats.Lives > 1 )
			livesText.text = PlayerStats.Lives.ToString() + " LIVES";
		else
			livesText.text = PlayerStats.Lives.ToString() + " LIFE";
	}
}
