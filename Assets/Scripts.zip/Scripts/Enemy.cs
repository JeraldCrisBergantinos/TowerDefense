using UnityEngine;

public class Enemy : MonoBehaviour {
	
	public float startSpeed = 10f;
	
	[HideInInspector]
	public float speed;
	
	public float offset = 0.2f;
	
	public float startHealth = 100f;
	public float regenHealth = 0.1f;
	private float health;
	
	public int moneyGain = 50;
	
	public GameObject deathEffect;
	public float skinThickness = 0.5f;
	
	public GameObject healthBar;
	
	void Start() {
		speed = startSpeed;
		health = startHealth;
	}
	
	void Update() {
		if ( health < startHealth ) {
			health += Time.deltaTime * startHealth * regenHealth;
		}
		else {
			health = startHealth;
		}
		
		Vector3 scale = healthBar.transform.localScale;
		scale.x = health / startHealth;
		healthBar.transform.localScale = scale;
	}
	
	public void TakeDamage( float amount ) {
		health -= amount;
		
		if ( health <= 0 ) {
			Die();
		}
	}
	
	public void Slow( float percent ) {
		speed = startSpeed * ( 1f - percent );
	}
	
	void Die() {
		if ( SoundLoop.instance.IsCorrectKeyPressed() ) {
			PlayerStats.Money += moneyGain;
		}
		
		GameObject effect = Instantiate( deathEffect, transform.position, Quaternion.identity ) as GameObject;
		Destroy( effect, 5f );
		
		WaveSpawner.EnemiesAlive--;
		
		Destroy( gameObject );
	}
}
