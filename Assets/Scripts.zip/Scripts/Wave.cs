using UnityEngine;

[System.Serializable]
public class Wave {
	
	public GameObject enemy;
	public int count;
	public float rate;
	
	public float speedMultiplier;
	public float healthMultiplier;
	public float healthRegenMultiplier;
	
	public bool infinite;
	public GameObject[] enemies;
		
}
