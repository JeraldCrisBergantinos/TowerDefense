-- INSTRUCTIONS --

These are the models and sprites used in the Tower Defense course available at http://youtube.com/brackeys.

Use the .fbx files unless you have Blender installed.
Use the .png files unless you have Photoshop installed.

-- GUIDELINES --

If you are unsure about how you are allowed to use the assets please see the Usage Guidelines: http://devassets.com/guidelines/

-- HAVE FUN --

I hope you will enjoy the contents of the pack!

(This pack was downloaded from http://devassets.com/.)